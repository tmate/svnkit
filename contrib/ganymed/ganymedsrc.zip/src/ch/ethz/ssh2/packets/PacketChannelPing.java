package ch.ethz.ssh2.packets;

/**
 * PacketPing.
 * 
 * @author Christian Plattner, plattner@inf.ethz.ch
 * @version $Id: PacketSessionStartShell.java,v 1.2 2005/08/24 17:54:09 cplattne Exp $
 */
public class PacketChannelPing
{
	byte[] payload;

	public int recipientChannelID;

	public PacketChannelPing(int recipientChannelID)
	{
		this.recipientChannelID = recipientChannelID;
	}

	public byte[] getPayload()
	{
		if (payload == null)
		{
			TypesWriter tw = new TypesWriter();
			tw.writeByte(Packets.SSH_MSG_CHANNEL_REQUEST);
			tw.writeUINT32(recipientChannelID);
			tw.writeString("ping");
			tw.writeBoolean(true);
			payload = tw.getBytes();
		}
		return payload;
	}
}
